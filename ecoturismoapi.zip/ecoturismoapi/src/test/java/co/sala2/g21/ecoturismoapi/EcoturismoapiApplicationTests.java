package co.sala2.g21.ecoturismoapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcoturismoapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
