package co.sala2.g21.ecoturismoapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcoturismoapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcoturismoapiApplication.class, args);
	}

}
